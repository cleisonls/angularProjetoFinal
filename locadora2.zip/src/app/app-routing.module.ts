import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ListarFilmesComponent } from './listar-filmes/listar-filmes.component';
import { DetalhesFilmesComponent } from './detalhes-filmes/detalhes-filmes.component';


const routes: Routes = [
  {path:'', component: HomeComponent},
  {path:'filmes', component: ListarFilmesComponent},
  {path:'filmes/:idfilme', component: DetalhesFilmesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

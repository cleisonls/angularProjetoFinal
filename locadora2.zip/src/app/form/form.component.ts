import { Component, OnInit, Input } from '@angular/core';
import { FilmesService } from "../filmes.service";
import { Filmes } from '../filmes';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  @Input() id

  filme = new Filmes()

  constructor(private FilmesService: FilmesService) { 
    
  }

  ngOnInit() {
    console.log(this.id)
    if (!isNaN(this.id) && this.id > 0) {
      var filme = this.FilmesService.getById(this.id);

      if(filme !== undefined){
        this.filme = filme
      }
    } else {
      this.filme.id = this.FilmesService.getNextId();
    }
  }

  onAdd(): void {
    this.FilmesService.add(this.filme)
    this.limpar()
  }

  limpar(): void {
    this.filme = new Filmes();
    let number = this.FilmesService.getNextId()
    this.filme.id = number;
  }

}

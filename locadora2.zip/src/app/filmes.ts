export class Filmes {
    id: number;
    titulo: string;
    genero: string;
    idioma: string;
    ano: string;
}
import { Injectable } from '@angular/core';
import { FILMES } from './mock-filmes';
import { Filmes } from './filmes';

@Injectable({
  providedIn: 'root'
})
export class FilmesService {

  constructor() {
    this.getFilmesDatabase();
  }

  getFilmesDatabase(){
    var session = sessionStorage.getItem('filmes');
    console.log(session);
    if(session === null){
      this.lfilme = FILMES
      sessionStorage.setItem('filmes',JSON.stringify(this.lfilme))
    }else{
      this.lfilme = JSON.parse(session)
    }
  }

  lfilme: Filmes[];

  getAll(): Filmes[]{
    return this.lfilme
  }

  getById(id: number){
    return this.lfilme[this.getPosicao(id)]
  }

  getLastid(){
    return this.getQtd() < 1 ? 0 : this.lfilme[this.getQtd()-1].id
  }

  getPosicao(id){
    var posicao = null
    this.lfilme.map(function(valores,chave){
      if (valores.id == id){
        posicao = chave
      }
    })
    return posicao
  }

  getQtd(){
    return this.lfilme.length
  }

  getNextId(){
    return this.getLastid()+1
  }

  add(filme){
    this.lfilme.push(filme)
    sessionStorage.setItem('filmes',JSON.stringify(this.lfilme))
  }

  removerFilme(id){
    this.lfilme.splice(this.getPosicao(id),1)
    sessionStorage.setItem('filmes',JSON.stringify(this.lfilme))
  }

  edit(id,dados:Filmes){
    var posicao = this.getPosicao(id)
    this.lfilme[posicao] = dados
    sessionStorage.setItem('filmes',JSON.stringify(this.lfilme))
  }

remove(id){
  var posicao = this.getPosicao(id)
  this.lfilme.splice(posicao,1)
  sessionStorage.setItem('filmes',JSON.stringify(this.lfilme))
}
}